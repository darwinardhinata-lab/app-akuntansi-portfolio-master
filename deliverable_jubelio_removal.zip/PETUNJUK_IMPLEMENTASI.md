# Petunjuk Implementasi — Penghapusan Integrasi Jubelio

## 1. File yang HARUS DIHAPUS dari project (tidak ada di paket ini karena memang harus lenyap)

```
app/Http/Controllers/Api/JubelioWebhookController.php
app/Http/Middleware/VerifyJubelioSignature.php
config/jubelio.php
app/Exports/PaymentPlanKasBankJubelioExport.php
app/Http/Controllers/ReconciliationController.php
app/Services/ReconciliationService.php
resources/views/reconciliation/index.blade.php
resources/views/reconciliation/reconciliation_index.blade.php
lang/zh_CN/erp_backup.php
update/                                    (seluruh folder — source patch reconciliation lama)
manufacturing-integration-final/           (seluruh folder — staging source lama, sudah ter-merge ke app/)
INTEGRASI_reconciliation.md
```

Command cepat (jalankan dari root project):
```bash
rm -f app/Http/Controllers/Api/JubelioWebhookController.php
rm -f app/Http/Middleware/VerifyJubelioSignature.php
rm -f config/jubelio.php
rm -f app/Exports/PaymentPlanKasBankJubelioExport.php
rm -f app/Http/Controllers/ReconciliationController.php
rm -f app/Services/ReconciliationService.php
rm -rf resources/views/reconciliation
rm -f lang/zh_CN/erp_backup.php
rm -rf update
rm -rf manufacturing-integration-final
rm -f INTEGRASI_reconciliation.md
```

**PENTING**: Sebelum menghapus `manufacturing-integration-final/`, verifikasi dulu di kondisi repo Anda saat ini bahwa folder ini memang tidak di-autoload (cek `composer.json` bagian `autoload.psr-4` — di analisa kami folder ini tidak termasuk path manapun di sana) dan bukan satu-satunya sumber untuk fitur manufaktur yang masih aktif. Kalau ternyata sudah berbeda dari saat analisa ini dibuat, JANGAN dihapus dulu.

## 2. File yang DIGANTI (timpa dengan isi paket ini)

```
lang/id/erp.php
lang/en/erp.php
lang/zh_CN/erp.php
resources/views/**   (87 file — sudah termasuk perbaikan zh_CN sebelumnya + penghapusan Jubelio)
app/Http/Controllers/CashFlowController.php
app/Http/Controllers/DocumentTraceController.php
app/Http/Controllers/JournalController.php
app/Http/Controllers/PaymentPlanController.php
app/Http/Controllers/ProductController.php
app/Http/Controllers/PurchaseOrderController.php
app/Http/Controllers/SalesOrderController.php
app/Http/Controllers/WarehouseController.php
app/Exports/PaymentPlanManualWorklistExport.php
app/Imports/AccountImport.php
app/Imports/JournalImport.php
app/Services/JournalCsvImportService.php
app/Services/PurchaseOrderService.php
app/Services/SalesOrderService.php
app/Jobs/ProcessPendingSOTempJob.php
app/Jobs/ProcessPendingTempJob.php
app/Models/JournalHeader.php
app/Models/PaymentCategory.php
app/Models/PaymentPlan.php
app/Models/SalesOrder.php
app/Console/Commands/FastImportJurnal.php
app/Console/Commands/FastImportPO.php
app/Console/Commands/FastSyncJurnal.php
app/Console/Commands/ImportHistoricalSales.php
routes/web.php
routes/api.php
```

## 3. File BARU (tambahkan, jangan timpa apa pun)

```
database/migrations/2026_09_10_100000_rename_jubelio_branded_columns.php
```

Migration ini me-rename kolom (BUKAN drop+create, data historis aman):
- `payment_categories.jubelio_flow` → `cash_bank_flow`
- `sales_orders.is_jubelio_shipment` → `is_marketplace_shipment`

Jalankan setelah semua file di atas diterapkan:
```bash
php artisan migrate
```

## 4. Perubahan perilaku (behavioral) yang perlu diketahui pengguna bisnis

- **Fitur "Rekonsiliasi Jubelio vs ERP" hilang total** (menu, halaman, route). Satu-satunya fungsi fitur ini adalah membandingkan data Jubelio vs ERP — karena Jubelio tidak dipakai lagi, seluruh fitur ini tidak relevan lagi.
- **Tombol/menu "Export Kas & Bank Jubelio" di Payment Plan hilang.** Payment category dengan flag `cash_bank_flow = 'KAS_BANK'` sekarang **tidak punya jalur export sama sekali** (sebelumnya diekspor ke format CSV Jubelio). Kalau bisnis masih butuh cara export data kas/bank ini ke suatu tempat, perlu didiskusikan jalur penggantinya — itu di luar scope "hapus Jubelio" murni.
- **Webhook endpoint `/api/jubelio/webhook/sales` sudah tidak ada.** Kalau ada sistem eksternal (termasuk Jubelio sendiri kalau ternyata masih jalan di sisi mereka) yang masih mengirim data ke endpoint ini, request tersebut akan gagal (404) mulai saat ini.
- Field form "Jubelio Shipment" di Sales Order (create/edit) sekarang bernama "Marketplace Shipment" — perilaku dan data tetap sama, cuma nama kolom & labelnya generik.
- 4 command Artisan (`jurnal:fast-import`, dst — cek nama signature masing-masing) **tetap berfungsi seperti biasa** untuk import CSV massal, cuma deskripsi & komentarnya sudah tidak menyebut Jubelio lagi. Ini BUKAN penghapusan fungsi, cuma rebranding, karena command-command ini adalah tool CSV import generik yang kebetulan tadinya dideskripsikan "dari Jubelio".

## 5. Yang SENGAJA tidak disentuh (butuh keputusan manusia terpisah)

- Dokumentasi markdown di root project (`ANALYSIS_REPORT.md`, `ARCHITECTURE.md`, `AUDIT_REPORT.md`, `DESIGN.md`, `FLOW_ANALYSIS_REPORT.md`, `MANUFACTURING_INTEGRATION.md`, `PAYMENT_PLAN_FIX_SUMMARY.md`, `PRD.md`, `RULES.md`) — sebagian menyebut Jubelio sebagai bagian dari catatan historis/analisa. Tidak diedit karena berpotensi mengubah keakuratan historis dokumen tersebut. Review manual disarankan kalau ingin dokumen ini fully rebranded juga.
- Migration lama (historis, yang PERTAMA membuat kolom `jubelio_flow`/`is_jubelio_shipment`) sengaja **tidak diubah** — mengubah migration yang sudah pernah dijalankan adalah praktik berbahaya di Laravel. Nama lama tetap ada di riwayat migration, itu normal.

## 6. Validasi yang WAJIB dijalankan agent setelah menerapkan semua di atas

Sama seperti validasi yang sudah kami jalankan sendiri sebelum paket ini dikirim (lihat `LAPORAN_PENGHAPUSAN_JUBELIO.md`):

```bash
php -l lang/id/erp.php lang/en/erp.php lang/zh_CN/erp.php
php artisan view:clear && php artisan config:clear && php artisan cache:clear
php artisan migrate
```

Lalu jalankan smoke test: buka halaman Sales Order (create/edit), Payment Plan (index), Journal (index), Purchase Order (index), Product (index), Dashboard — pastikan tidak ada error 500, tidak ada teks translasi yang tampil sebagai raw key (`erp.xxx`), dan pastikan menu "Rekonsiliasi" sudah tidak muncul lagi di sidebar.
