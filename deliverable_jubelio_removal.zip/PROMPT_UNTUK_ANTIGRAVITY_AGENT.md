# Prompt untuk Agent Antigravity — Implementasi Gabungan: Perbaikan zh_CN + Penghapusan Jubelio

Copy-paste seluruh blok di bawah ini (dari `---MULAI PROMPT---` sampai `---AKHIR PROMPT---`) ke chat agent Antigravity di root project `app-akuntansi-portfolio`.

Sebelum menjalankan, letakkan `deliverable_jubelio_removal.zip` di root project. Paket ini **sudah menggabungkan** perbaikan terjemahan zh_CN sebelumnya DAN penghapusan integrasi Jubelio — jadi ini satu-satunya paket yang perlu diterapkan (menggantikan paket zh_CN yang lama, kalau itu belum pernah diterapkan).

---MULAI PROMPT---

Kamu adalah agent coding yang bekerja di root repository Laravel `app-akuntansi-portfolio`. Tugasmu mengimplementasikan dua batch perubahan sekaligus yang sudah disiapkan dalam `deliverable_jubelio_removal.zip`:

1. **Perbaikan lokalisasi zh_CN menyeluruh** — dari 3/88 file Blade yang pakai `__()`, sekarang 87/88 file sudah pakai `__('erp.xxx')`, plus perbaikan beberapa bug pre-existing di lang files (key korup, key hilang, key duplikat).
2. **Penghapusan total integrasi Jubelio** — webhook, middleware, config, fitur reconciliation, console command wording, kolom database di-rename, dan seluruh sisa referensi "Jubelio" di codebase (kecuali dokumentasi markdown historis dan migration lama).

## Konteks penting — baca sebelum eksekusi

**Jubelio adalah/pernah menjadi integrasi bisnis AKTIF**, bukan sekadar istilah UI. Sebelum paket ini dibuat, ditemukan bahwa Jubelio terhubung lewat webhook real-time yang otomatis membuat Sales Invoice dan posting jurnal akuntansi. Keputusan untuk menghapus total ini SUDAH dikonfirmasi eksplisit oleh pemilik project ("Jubelio sudah tidak dipakai lagi"). **JANGAN membatalkan atau meragukan keputusan ini** — tapi tetap ikuti langkah verifikasi di bawah karena kondisi repo bisa saja sudah berubah sejak analisa dibuat.

**PENTING — risiko konflik**: File-file dalam paket ini diproses dari SATU snapshot repo pada waktu tertentu (10 September 2026). Kalau ada perubahan lain di repo SETELAH snapshot itu (developer lain commit, atau perubahan manual), overwrite langsung BISA menghilangkan perubahan tersebut. Proses di bawah ini WAJIB pakai `git diff`/`git status` untuk cek dulu.

## Langkah 1 — Persiapan & backup

1. `git status` — kalau ada uncommitted changes penting, konfirmasi ke user dulu atau stash.
2. `git checkout -b fix/zh-cn-and-remove-jubelio`
3. Extract ke folder sementara di luar working tree:
   ```
   mkdir -p /tmp/combined_fix
   unzip deliverable_jubelio_removal.zip -d /tmp/combined_fix
   ```
4. Baca `PETUNJUK_IMPLEMENTASI.md` dan `LAPORAN_PENGHAPUSAN_JUBELIO.md` di dalam hasil extract — dua dokumen ini berisi daftar lengkap file yang harus dihapus/ditimpa/ditambahkan beserta alasannya. JANGAN skip membaca ini.

## Langkah 2 — Hapus file yang memang harus lenyap

Ikuti persis daftar "1. File yang HARUS DIHAPUS" di `PETUNJUK_IMPLEMENTASI.md`. Sebelum menjalankan `rm`, untuk SETIAP file/folder yang akan dihapus:

1. Cek dulu apakah file/folder itu **masih dipakai** di kondisi repo SAAT INI (bukan asumsi dari laporan) — khususnya:
   - `manufacturing-integration-final/` — pastikan tidak ada di `composer.json` autoload path, dan pastikan fitur manufaktur di `app/Modules/Manufacturing` atau `app/` (lokasi sudah live) benar-benar sudah lengkap tanpa folder ini.
   - File-file terkait Reconciliation — pastikan tidak ada route atau link lain di luar yang sudah diketahui yang masih mengarah ke controller/service ini.
2. Kalau ada keraguan pada satu file, SKIP dulu file itu dan laporkan ke user, jangan dihapus paksa.
3. Hapus yang sudah pasti aman sesuai daftar.

## Langkah 3 — Cek konflik sebelum menerapkan file kategori "diganti"

Untuk SETIAP file di daftar "2. File yang DIGANTI" di `PETUNJUK_IMPLEMENTASI.md`:

1. `diff -u <file_repo_saat_ini> <file_di_paket>`.
2. Kelompokkan:
   - **A. Aman ditimpa** — beda cuma karena penambahan `__('erp.xxx')` atau penghapusan kode Jubelio.
   - **B. Ada perubahan lain di repo** yang tidak ada di file paket (field baru, bugfix lain, dsb) — JANGAN ditimpa mentah. Merge manual: pertahankan perubahan lain dari repo, terapkan pola penghapusan-Jubelio dan penambahan-`__()` yang sama secara manual.
3. Laporkan ringkasan A vs B sebelum lanjut. Untuk kategori B, jelaskan konfliknya satu-satu sebelum melakukan merge.

Untuk `lang/id/erp.php`, `lang/en/erp.php`, `lang/zh_CN/erp.php` — JANGAN overwrite langsung kalau repo sudah punya key baru yang tidak ada di file paket. Gabungkan (union) key dari kedua sumber. Kalau ada key sama dengan value beda, pertahankan value dari paket (sudah di-QA), tapi catat key mana yang berubah untuk direview manusia.

## Langkah 4 — Terapkan file kategori "baru"

Copy `database/migrations/2026_09_10_100000_rename_jubelio_branded_columns.php` ke `database/migrations/`. Ini migration `renameColumn` (bukan drop+create), aman untuk data yang sudah ada. Jangan edit migration lama yang membuat kolom `jubelio_flow`/`is_jubelio_shipment` pertama kali — itu harus tetap seperti riwayat aslinya.

## Langkah 5 — Validasi wajib (jangan skip satupun)

1. **Syntax check PHP** pada seluruh file yang disentuh, minimal:
   ```
   php -l lang/id/erp.php lang/en/erp.php lang/zh_CN/erp.php
   find app database/migrations routes config -name "*.php" -exec php -l {} \; | grep -v "No syntax errors"
   ```
   Baris kedua harus tidak menghasilkan output apapun (artinya semua lolos).

2. **Cek semua `__('erp.XXX')` yang dipakai di views ada di ketiga file lang** — tulis script kecil yang mengumpulkan semua pemanggilan, load ketiga array via `include`, laporkan key yang hilang di salah satu bahasa. Target: 0 yang hilang.

3. **Cek tidak ada referensi ke class/route yang sudah dihapus**:
   ```
   grep -rln "ReconciliationController\|ReconciliationService\|JubelioWebhookController\|VerifyJubelioSignature\|PaymentPlanKasBankJubelioExport" --include="*.php" --include="*.blade.php" .
   grep -rln "route('reconciliation\.\|route('payment.export.kasbank" --include="*.php" --include="*.blade.php" .
   ```
   Kedua command harus tidak menghasilkan output (kecuali di dalam file yang memang sengaja belum dihapus/di luar scope, misal dokumentasi markdown).

4. **Cek duplicate array key** di lang files (array literal PHP dengan key duplikat akan silently override):
   ```
   php -r '
   foreach (["lang/id/erp.php","lang/en/erp.php","lang/zh_CN/erp.php"] as $f) {
       $content = file_get_contents($f);
       preg_match_all("/\x27([a-zA-Z0-9_]+)\x27\s*=>\s*\x27/", $content, $m);
       $counts = array_count_values($m[1]);
       $dupes = array_filter($counts, fn($c) => $c > 1);
       echo "$f: " . count($dupes) . " duplicate keys\n";
   }
   '
   ```
   Kalau ada duplicate BARU dari proses merge Langkah 3 (bukan yang sudah diketahui dari laporan), itu wajib diperbaiki.

5. **Clear cache Laravel**:
   ```
   php artisan view:clear
   php artisan config:clear
   php artisan cache:clear
   ```

6. **Jalankan migration**:
   ```
   php artisan migrate
   ```
   Pastikan tidak ada error. Kalau environment migration terhubung ke DB produksi, JANGAN jalankan otomatis — laporkan ke user dan minta konfirmasi eksplisit sebelum migrate di DB produksi.

7. **Jalankan test suite** kalau ada. Fokus khusus ke test yang menyentuh Sales Order, Payment Plan, Journal — karena field/kolom di-rename dan ada method yang dihapus.

8. **Smoke test manual**: buka aplikasi, cek halaman berikut satu-satu, pastikan tidak ada error 500 dan tidak ada teks translasi yang tampil sebagai raw key (`erp.xxx`):
   - Dashboard
   - Sales Order (index, create, edit) — khususnya field "Marketplace Shipment"
   - Payment Plan (index, create) — pastikan tombol export tidak lagi menyebut "Jubelio" dan tidak error saat diklik
   - Journal (index)
   - Purchase Order (index)
   - Product (index)
   - Sidebar menu — pastikan menu "Rekonsiliasi" sudah tidak muncul
   - Coba akses `/reconciliation` langsung di browser — harus menghasilkan 404, bukan error 500
   - Switch locale ke zh_CN, ulangi cek di 3-4 halaman berbeda

## Langkah 6 — Item yang butuh keputusan manusia (jangan diputuskan sendiri)

Laporkan ke user, jangan langsung eksekusi tanpa konfirmasi:

1. Payment category dengan `cash_bank_flow = 'KAS_BANK'` sekarang **tidak punya jalur export sama sekali** setelah export Jubelio dihapus. Tanyakan apakah bisnis masih butuh cara export data ini ke suatu tempat.
2. Webhook `/api/jubelio/webhook/sales` sekarang 404. Kalau ternyata masih ada sistem eksternal manapun (termasuk Jubelio sendiri) yang mengirim data ke endpoint ini, mereka akan mulai gagal — pastikan ini memang yang diinginkan.
3. 9 file dokumentasi markdown (`ANALYSIS_REPORT.md`, `ARCHITECTURE.md`, `AUDIT_REPORT.md`, `DESIGN.md`, `FLOW_ANALYSIS_REPORT.md`, `MANUFACTURING_INTEGRATION.md`, `PAYMENT_PLAN_FIX_SUMMARY.md`, `PRD.md`, `RULES.md`) masih menyebut Jubelio sebagai catatan historis — tidak disentuh, tanyakan apakah user mau di-rebrand juga.
4. Duplicate key pre-existing di `lang/en/erp.php` dan `lang/zh_CN/erp.php` (lihat detail di laporan zh_CN sebelumnya) — sudah diverifikasi tidak menyebabkan bug, tapi technical debt. Tanyakan apakah mau dijadwalkan sesi cleanup terpisah.

## Langkah 7 — Commit & laporan akhir

1. Setelah semua validasi Langkah 5 lolos dan tidak ada item Langkah 6 yang mengganjal:
   ```
   git add -A
   git commit -m "fix(i18n): comprehensive zh_CN localization + remove Jubelio integration

   zh_CN localization:
   - 87/88 Blade views now use __('erp.xxx'), up from 3/88
   - Fixed pre-existing corrupted/missing/duplicate translation keys

   Jubelio integration removal (business confirmed no longer in use):
   - Removed webhook controller, signature middleware, config, and the
     entire Reconciliation feature (controller + 745-line service + views)
   - Renamed jubelio_flow -> cash_bank_flow, is_jubelio_shipment ->
     is_marketplace_shipment via safe renameColumn migration
   - Generalized CSV import command descriptions (functionality unchanged)
   - Removed stale staging folders (update/, manufacturing-integration-final/)
   - Cleaned 43 Jubelio-branded translation keys
   - All PHP syntax validated (php -l), all __() keys verified to resolve
   "
   ```
2. Buat laporan ringkas ke user berisi: hasil validasi Langkah 5 (pass/fail), daftar file kategori B yang perlu merge manual beserta hasilnya, dan 4 item dari Langkah 6 yang masih menunggu keputusan.
3. **JANGAN merge ke branch utama secara otomatis dan JANGAN jalankan `php artisan migrate` di database produksi tanpa konfirmasi eksplisit.** Berhenti di branch terpisah, tunggu review dari user.

---AKHIR PROMPT---
