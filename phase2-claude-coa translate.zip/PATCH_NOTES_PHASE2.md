# Phase 2 — Patch Notes

## File baru (copy langsung ke path yang sama)

- `app/Console/Commands/AuditCoaTypeMismatch.php` — read-only, jalankan duluan:
  `php artisan coa:audit-type-mismatch`
  (Laravel 12 auto-discover command di app/Console/Commands, tidak perlu
  registrasi manual -- cek `php artisan list | grep coa` untuk pastikan muncul)
- `app/Jobs/TranslateAccountNamesJob.php`

## File yang DIGANTI PENUH (full file, bukan diff — ukuran file kecil)

- `app/Imports/AccountImport.php`
  - FIX: pengenalan kata kunci Mandarin (借/贷, 资产负债表/损益表) untuk Pos Saldo
    & Pos Laporan, sebelumnya cuma bahasa Inggris
  - FIX: Log::warning kalau ada baris yang tidak dikenali (sebelumnya silent
    fallback ke DEBET/NERACA tanpa jejak apa pun)
  - FIX: dispatch `TranslateAccountNamesJob` 1x per batch import
  - **coa_type mapping SENGAJA belum diubah** — lihat temuan kritis di bawah
- `app/Exports/AccountExport.php`
  - FIX: tambah `WithMapping`, export sekarang locale-aware
    (`translatedName()`/`translatedCoaType()`/dst dari Phase 1) — kolom
    mentah di DB tidak berubah, ini murni transformasi output

## 🔴 Temuan kritis (BUKAN bug baru dari patch ini — sudah ada sebelumnya)

Saat menyiapkan fix ZH_CN, saya audit `resources/views/account/create.blade.php`
dan `edit.blade.php`. Keduanya punya dropdown `coa_type` dengan **15 kategori
resmi** (Cash & Bank, Piutang Dagang, Persediaan, Aset Lancar Lainnya, Aset
Tetap, Investasi Jangka Panjang, Hutang Dagang, Hutang Lainnya, Hutang Jangka
Panjang, Modal, Pendapatan, Pendapatan Lainnya, Harga Pokok Penjualan, Biaya,
Biaya Lainnya).

Tapi 3 template CSV yang Anda kirim punya **27 sub-kategori** yang lebih detail
(Piutang (Aset Lancar), Piutang Lain-lain, Uang Muka & Biaya, Pajak Bayar
Dimuka, Jaminan, Aset Tetap, Akumulasi Penyusutan Aset Tetap, dst) — dan nama
kategorinya **tidak ada satu pun yang persis sama** dengan 15 kategori di
dropdown itu.

Efeknya: akun yang diimport dari CSV manapun (ID/EN/ZH, sudah dari dulu, bukan
cuma isu Mandarin) akan punya `coa_type` yang **tidak match opsi dropdown
apa pun**. Kalau akun itu dibuka di form Edit, dropdown "Tipe Akun" tampil
kosong (tidak ada yang ter-select) — kalau user save tanpa sadar pilih ulang
kategori, `coa_type` asli bisa **tertimpa jadi kategori yang salah**, karena
field itu `required` jadi user dipaksa pilih sesuatu.

Ini kemungkinan sudah lama ada (independen dari isu bahasa/translation yang
kita kerjakan), makanya saya buatkan `AuditCoaTypeMismatch` di atas — jalankan
itu dulu untuk lihat skala dampaknya di data Anda sekarang, sebelum saya
sentuh logic mapping `coa_type` di `AccountImport.php`.

**Saya belum mengubah apa pun terkait ini** karena butuh keputusan bisnis
Anda: 27 sub-kategori itu mau dipetakan ke 15 kategori resmi yang mana (butuh
judgement akuntansi, bukan sesuatu yang saya tebak), atau dropdown-nya yang
diperluas jadi 27, atau pendekatan lain. Setelah hasil `coa:audit-type-mismatch`
dan keputusan Anda, saya siapkan patch-nya di iterasi berikutnya.
