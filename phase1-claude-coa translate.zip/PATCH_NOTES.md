# Phase 1 — Patch Notes

File baru (tinggal copy ke path yang sama di repo, lalu `php artisan migrate`):

- `database/migrations/2026_09_16_100000_create_account_translations_table.php`
- `database/migrations/2026_09_16_100001_create_coa_type_translations_table.php`
- `app/Models/AccountTranslation.php`
- `app/Models/CoaTypeTranslation.php`
- `app/Services/AccountTranslationService.php`

File EXISTING yang perlu ditambah manual (targeted diff, bukan overwrite):

## 1. `config/services.php` — tambahkan blok ini di dalam array return, sebelum `];` penutup

```php
    'deepl' => [
        'key' => env('DEEPL_API_KEY'),
        // FIX: default arahkan ke host FREE tier DeepL (api-free.deepl.com).
        // Kalau nanti upgrade ke DeepL Pro, ganti ke https://api.deepl.com/v2/translate
        // dan pakai API key Pro (tidak berakhiran ":fx").
        'endpoint' => env('DEEPL_API_ENDPOINT', 'https://api-free.deepl.com/v2/translate'),
    ],
```

Lalu tambahkan ke `.env`:
```
DEEPL_API_KEY=xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx:fx
```

Cara daftar API key gratis (5 menit, tanpa kartu kredit):
1. Buka https://www.deepl.com/pro-api
2. Pilih paket "DeepL API Free"
3. Setelah daftar & verifikasi email, API key ada di halaman akun -> tab "API keys"
   (key free tier selalu berakhiran `:fx`)
4. Kuota: 50.000 karakter/bulan, reset tiap bulan, tanpa kartu kredit

## 2. `app/Models/Account.php` — tambahkan use statement + 4 method baru

Tambahkan setelah `use Illuminate\Database\Eloquent\Relations\HasMany;`:
```php
use Illuminate\Database\Eloquent\Relations\HasMany;
use App\Models\AccountTranslation;
use App\Models\CoaTypeTranslation;
```

Tambahkan di dalam class `Account`, setelah method `journalDetails()`:

```php
    /**
     * Relasi ke override translation untuk account_name (locale non-default).
     */
    public function translations(): HasMany
    {
        return $this->hasMany(AccountTranslation::class, 'account_code', 'account_code');
    }

    /**
     * Nama akun sesuai locale aktif (atau locale yang diminta).
     * Locale 'id' (default) selalu ambil dari kolom account_name asli,
     * TIDAK query ke account_translations -- supaya tidak ada perubahan
     * perilaku sama sekali untuk locale default.
     */
    public function translatedName(?string $locale = null): string
    {
        $locale = $locale ?? app()->getLocale();

        if ($locale === 'id') {
            return $this->account_name;
        }

        $override = $this->relationLoaded('translations')
            ? $this->translations->firstWhere('locale', $locale)
            : $this->translations()->where('locale', $locale)->first();

        return $override?->name ?? $this->account_name;
    }

    /**
     * Label coa_type sesuai locale aktif, dari kamus coa_type_translations.
     * Kolom coa_type ASLI tidak pernah diubah -- WHERE coa_type = ... di
     * AccountController/AccountExport tetap aman, ini murni untuk tampilan.
     */
    public function translatedCoaType(?string $locale = null): string
    {
        $locale = $locale ?? app()->getLocale();

        if ($locale === 'id' || empty($this->coa_type)) {
            return $this->coa_type;
        }

        return CoaTypeTranslation::labelFor($this->coa_type, $locale) ?? $this->coa_type;
    }

    /**
     * Label Pos Saldo (DEBET/KREDIT) sesuai locale aktif.
     * Pakai lang key yang SUDAH ADA di lang/{locale}/erp.php (debit_caps,
     * credit_caps) -- tidak perlu tabel/migration baru untuk kolom ini.
     */
    public function translatedNormalBalance(): string
    {
        return $this->normal_balance === 'KREDIT'
            ? __('erp.credit_caps')
            : __('erp.debit_caps');
    }

    /**
     * Label Pos Laporan (NERACA/LABA RUGI) sesuai locale aktif.
     * Sama seperti di atas, reuse lang key existing (balance_sheet_caps,
     * profit_loss_caps).
     */
    public function translatedReportPos(): string
    {
        return $this->report_pos === 'LABA RUGI'
            ? __('erp.profit_loss_caps')
            : __('erp.balance_sheet_caps');
    }
```

## Yang SENGAJA belum disentuh di Phase 1 (butuh approval terpisah)

- `AccountImport.php` — belum diubah. Ini tempat bug normalisasi ZH_CN
  (fallback diam-diam ke DEBET/NERACA) dan tempat pemanggilan
  `AccountTranslationService::translateAccountNames()` /
  `translateCoaTypes()` nantinya akan di-dispatch setelah import selesai.
- `AccountController.php` / view `account/*.blade.php` — belum ada yang
  dipanggilkan `translatedName()`/`translatedCoaType()` dkk. Listing dan
  laporan masih tampil apa adanya (locale id) sampai wiring ini dikerjakan.
- Tidak ada Job/queue dispatch dulu — `AccountTranslationService` sudah
  bisa dipanggil manual/via tinker untuk testing, sebelum di-wire ke job.

## Cara test setelah migrate (tanpa ubah file lain dulu)

```
php artisan migrate
php artisan tinker
>>> app(\App\Services\AccountTranslationService::class)->translateAccountNames(['111001','114001']);
>>> \App\Models\AccountTranslation::all();
```
