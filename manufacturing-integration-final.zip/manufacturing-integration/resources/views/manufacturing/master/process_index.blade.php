@extends('layouts.app')

@section('top_bar_left')
    <x-breadcrumb :links="['Manufaktur' => '#', 'Master Rate Proses' => null]" />
@endsection

@section('content')
<div class="container-fluid px-0">
    <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center mb-4 gap-3">
        <div>
            <h3 class="fw-bold mb-1 text-dark">Master Rate Proses (Jasa Vendor)</h3>
            <p class="text-muted small mb-0">Rate default per kg/pcs untuk knitting, dyeing, printing, finishing, cutting, stitching.</p>
        </div>
        <div class="d-flex gap-2 flex-wrap">
            <a href="{{ route('mfg.processes.index', ['export' => 'excel']) }}" class="btn btn-success fw-bold px-3 shadow-sm">
                <i class="fa-solid fa-file-excel me-1"></i> Export
            </a>
            <button type="button" class="btn btn-info text-white fw-bold px-3 shadow-sm" data-bs-toggle="modal" data-bs-target="#modalImport">
                <i class="fa-solid fa-file-import me-1"></i> Import
            </button>
            <button type="button" class="btn btn-primary fw-bold px-3 shadow-sm" data-bs-toggle="modal" data-bs-target="#modalCreate">
                <i class="fa-solid fa-plus me-1"></i> Tambah Proses
            </button>
        </div>
    </div>

    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show shadow-sm">{{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
    @endif
    @if(session('error'))
        <div class="alert alert-danger alert-dismissible fade show shadow-sm">{{ session('error') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
    @endif

    <div class="card shadow-sm border-0 mb-4">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-bordered table-striped table-hover align-middle mb-0 text-nowrap" style="font-size: 13.5px;">
                    <thead class="bg-primary text-white text-center align-middle">
                        <tr>
                            <th>Nama Proses</th><th>Tipe</th><th>Satuan Rate</th><th>Rate</th>
                            <th>Vendor Default</th><th>Status</th><th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse ($processes as $process)
                            <tr>
                                <td class="fw-bold py-2">{{ $process->process_name }}</td>
                                <td class="text-center py-2"><span class="badge bg-info text-dark">{{ $process->process_type }}</span></td>
                                <td class="text-center py-2">{{ $process->rate_unit }}</td>
                                <td class="text-end py-2">Rp {{ number_format($process->process_rate, 2) }}</td>
                                <td class="py-2">{{ $process->defaultSupplier->supplier_name ?? '-' }}</td>
                                <td class="text-center py-2">
                                    <span class="badge {{ $process->is_active ? 'bg-success' : 'bg-secondary' }}">{{ $process->is_active ? 'AKTIF' : 'NONAKTIF' }}</span>
                                </td>
                                <td class="text-center py-2">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-sm btn-outline-warning" data-bs-toggle="modal"
                                            data-bs-target="#modalEdit{{ $process->id }}"><i class="fas fa-edit"></i></button>
                                        <form action="{{ route('mfg.processes.destroy', $process->id) }}" method="POST" class="d-inline"
                                            onsubmit="return confirm('Yakin hapus rate proses ini?')">
                                            @csrf @method('DELETE')
                                            <button type="submit" class="btn btn-sm btn-outline-danger"><i class="fas fa-trash"></i></button>
                                        </form>
                                    </div>
                                </td>
                            </tr>

                            <div class="modal fade" id="modalEdit{{ $process->id }}" tabindex="-1">
                                <div class="modal-dialog">
                                    <form action="{{ route('mfg.processes.update', $process->id) }}" method="POST">
                                        @csrf @method('PUT')
                                        <div class="modal-content">
                                            <div class="modal-header"><h5 class="modal-title">Edit Rate Proses</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
                                            <div class="modal-body">
                                                <div class="mb-2"><label class="form-label">Tipe Proses</label>
                                                    <select name="process_type" class="form-select" required>
                                                        @foreach(['KNITTING','DYEING','PRINTING','FINISHING','CUTTING','STITCHING','OTHER'] as $type)
                                                            <option value="{{ $type }}" {{ $process->process_type === $type ? 'selected' : '' }}>{{ $type }}</option>
                                                        @endforeach
                                                    </select></div>
                                                <div class="mb-2"><label class="form-label">Nama Proses</label>
                                                    <input type="text" name="process_name" class="form-control" value="{{ $process->process_name }}" required></div>
                                                <div class="mb-2"><label class="form-label">Satuan Rate</label>
                                                    <select name="rate_unit" class="form-select" required>
                                                        <option value="PER_KG" {{ $process->rate_unit === 'PER_KG' ? 'selected' : '' }}>Per KG</option>
                                                        <option value="PER_PCS" {{ $process->rate_unit === 'PER_PCS' ? 'selected' : '' }}>Per PCS</option>
                                                    </select></div>
                                                <div class="mb-2"><label class="form-label">Rate (Rp)</label>
                                                    <input type="number" step="0.01" name="process_rate" class="form-control" value="{{ $process->process_rate }}" required></div>
                                                <div class="mb-2"><label class="form-label">Vendor Default</label>
                                                    <select name="default_supplier_id" class="form-select">
                                                        <option value="">-- Tidak ada --</option>
                                                        @foreach($suppliers as $s)
                                                            <option value="{{ $s->id }}" {{ $process->default_supplier_id == $s->id ? 'selected' : '' }}>{{ $s->supplier_name }}</option>
                                                        @endforeach
                                                    </select></div>
                                                <div class="form-check">
                                                    <input type="checkbox" name="is_active" class="form-check-input" value="1" {{ $process->is_active ? 'checked' : '' }}>
                                                    <label class="form-check-label">Aktif</label>
                                                </div>
                                            </div>
                                            <div class="modal-footer"><button type="submit" class="btn btn-primary">Simpan</button></div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        @empty
                            <tr><td colspan="7" class="text-center py-5 text-muted">Belum ada data rate proses.</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    {{ $processes->links() }}
</div>

<div class="modal fade" id="modalCreate" tabindex="-1">
    <div class="modal-dialog">
        <form action="{{ route('mfg.processes.store') }}" method="POST">
            @csrf
            <div class="modal-content">
                <div class="modal-header"><h5 class="modal-title">Tambah Rate Proses</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
                <div class="modal-body">
                    <div class="mb-2"><label class="form-label">Tipe Proses</label>
                        <select name="process_type" class="form-select" required>
                            <option value="KNITTING">KNITTING</option>
                            <option value="DYEING">DYEING</option>
                            <option value="PRINTING">PRINTING</option>
                            <option value="FINISHING">FINISHING</option>
                            <option value="CUTTING">CUTTING</option>
                            <option value="STITCHING">STITCHING</option>
                            <option value="OTHER">OTHER</option>
                        </select></div>
                    <div class="mb-2"><label class="form-label">Nama Proses</label>
                        <input type="text" name="process_name" class="form-control" required placeholder="Knitting Single Jersey"></div>
                    <div class="mb-2"><label class="form-label">Satuan Rate</label>
                        <select name="rate_unit" class="form-select" required>
                            <option value="PER_KG">Per KG</option>
                            <option value="PER_PCS">Per PCS</option>
                        </select></div>
                    <div class="mb-2"><label class="form-label">Rate (Rp)</label>
                        <input type="number" step="0.01" name="process_rate" class="form-control" required></div>
                    <div class="mb-2"><label class="form-label">Vendor Default</label>
                        <select name="default_supplier_id" class="form-select">
                            <option value="">-- Tidak ada --</option>
                            @foreach($suppliers as $s)
                                <option value="{{ $s->id }}">{{ $s->supplier_name }}</option>
                            @endforeach
                        </select></div>
                </div>
                <div class="modal-footer"><button type="submit" class="btn btn-primary">Simpan</button></div>
            </div>
        </form>
    </div>
</div>

<div class="modal fade" id="modalImport" tabindex="-1">
    <div class="modal-dialog">
        <form action="{{ route('mfg.processes.import') }}" method="POST" enctype="multipart/form-data">
            @csrf
            <div class="modal-content">
                <div class="modal-header"><h5 class="modal-title">Import Master Rate Proses</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button></div>
                <div class="modal-body">
                    <div class="alert alert-info small">
                        <i class="fa-solid fa-info-circle me-1"></i> Gunakan susunan kolom template.
                        <a href="{{ route('mfg.processes.download-template') }}" class="fw-bold">Download Template</a>
                    </div>
                    <div class="mb-2">
                        <label class="form-label">Pilih File (.xlsx/.xls/.csv)</label>
                        <input type="file" name="file_excel" class="form-control" required accept=".xlsx,.xls,.csv">
                    </div>
                    <div class="form-text">Data selalu ditambahkan baru (tidak ada kode unik utk update), edit rate lama lewat tombol Edit di tabel.</div>
                </div>
                <div class="modal-footer"><button type="submit" class="btn btn-primary fw-bold">Mulai Import</button></div>
            </div>
        </form>
    </div>
</div>
@endsection
